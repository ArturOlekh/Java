import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: Задание 1.
        //Пользователь вводит, сколько лет он состоит в браке. Программа должна вывести, какая годовщина свадьбы будет
        // у пользователя следующей (бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать
        // все годовщины, достаточно 10-15. Узнать про годовщины можно, например,
        // здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
        //
        //Задание 2.
        //Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит свой выбор
        // (в виде строки или числа - выберите что-то одно). Программа случайным образом делает свой выбор и
        // выводит на экран. Далее программа показывает, кто победитель – пользователь или программа.
        System.out.println("Задание №1");
        System.out.println();
        Scanner scr = new Scanner(System.in);
        System.out.println("Сколько лет вы состоите в браке?  ");
        int intAnniversary = scr.nextInt() + 1;

        String anniversary = switch (intAnniversary) {
            case 1 -> Anniversary.PAPER.name();
            case 2 -> Anniversary.COTTON.name();
            case 3 -> Anniversary.LEATHER.name();
            case 4 -> Anniversary.FRUIT.name();
            case 5 -> Anniversary.WOOD.name();
            case 6 -> Anniversary.SUGAR.name();
            case 7 -> Anniversary.COPPER.name();
            case 8 -> Anniversary.BRONZE.name();
            case 9 -> Anniversary.WILLOW.name();
            case 10 -> Anniversary.TIN.name();
            case 11 -> Anniversary.STEEL.name();
            case 12 -> Anniversary.SILK.name();
            case 13 -> Anniversary.LACE.name();
            case 14 -> Anniversary.IVORY.name();
            case 15 -> Anniversary.CRYSTAL.name();
            default -> "Такой годовщины нет в списке";

        };
        System.out.println("Следующая годовщина " + anniversary);
        System.out.println();
        System.out.println("Задание №2");
        System.out.println();
        System.out.println("Введите 1 = камень, 2 = ножницы, 3 = бумага  ");
        int i1 = scr.nextInt();
        StoneScissorsPaper user = getChoice (i1);

        StoneScissorsPaper comp = getChoice (new Random().nextInt(1, 4));

        System.out.println("Компьютер выбрал " + comp);
        if (user == comp) {
            System.out.println("Ничья");
        } else {
            if (user == StoneScissorsPaper.SCISSORS && comp == StoneScissorsPaper.PAPERS ||
                    user == StoneScissorsPaper.STONE && comp == StoneScissorsPaper.SCISSORS ||
                    user == StoneScissorsPaper.PAPERS && comp == StoneScissorsPaper.STONE){
                System.out.println("Победил пользователь");
            }else {
                System.out.println("Победил компьютер");
            }
            String game = user == comp ? "Ничья" : (user == StoneScissorsPaper.SCISSORS && comp ==
                    StoneScissorsPaper.PAPERS ||
                    user == StoneScissorsPaper.STONE && comp == StoneScissorsPaper.SCISSORS ||
                    user == StoneScissorsPaper.PAPERS && comp == StoneScissorsPaper.STONE ? "Победил пользователь" :
                    "Победил компьютер");
            System.out.println(game);
        }

    }

    private static StoneScissorsPaper getChoice (int choice){
        return switch (choice) {
            case 1 -> StoneScissorsPaper.STONE;
            case 2 -> StoneScissorsPaper.SCISSORS;
            case 3 -> StoneScissorsPaper.PAPERS;
            default -> throw new RuntimeException("Введено неверное значение");

        };
    }
}