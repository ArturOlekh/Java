public enum StoneScissorsPaper {
    STONE,
    SCISSORS,
    PAPERS
}
