import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: Двумерные массивы
        //Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
        // Буква Ё должна быть на своём месте.
        char[][] rusAlphArray = new char[6][5];
        char current = 'А';
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                rusAlphArray[i][j] = current;
                if (current == 'Е') {
                    current = 'Ё';
                } else {
                    current++;
                }
            }
        }
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(rusAlphArray[i][j] + " ");
            }
        }
        //        Строки
        //№1
        //Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
        //Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.
        //Например:
        //ввод - mama, papa
        //вывод - mapa
        Scanner scanner = new Scanner(System.in);

        // Ввод двух слов
        System.out.println();
        System.out.print("Введите первое слово: ");
        String first = scanner.nextLine();
        System.out.print("Введите второе слово: ");
        String second = scanner.nextLine();

        if (first.length() % 2 == 0 && second.length() % 2 == 0) {
            int halfLength1 = first.length() / 2;
            int halfLength2 = second.length() / 2;
            String one = first.substring(0, halfLength1) + second.substring(halfLength2);
            System.out.println(first + ", " + second);
            System.out.println(one);
        } else {
            System.out.println("Оба слова должны иметь четное количество букв.");
        }
        //Создайте строку через new - I study Basic Java!
        //Напишите метод, который принимает в качестве параметра строку, передайте в этот метод строку,
        // которую создали в п.1
        //Распечатать последний символ строки. Используем метод String.charAt().
        //Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().
        //Заменить все символы “а” на “о”.
        //Преобразуйте строку к верхнему регистру.
        //Преобразуйте строку к нижнему регистру.
        //Вырезать строку Java c помощью метода String.substring().
        String myString = new String("I study Basic Java!");
        getString(myString);
    }
    static void getString(String inputString) {
        char lastChar = inputString.charAt(inputString.length() - 1);
        System.out.println("Последний символ строки: " + lastChar);
        boolean containsJava = inputString.contains("Java");
        System.out.println("Содержит подстроку 'Java': " + containsJava);
        String replacedString = inputString.replace('a', 'o');
        System.out.println("Строка после замены 'a' на 'o': " + replacedString);
        String uppercaseString = inputString.toUpperCase();
        System.out.println("Строка в верхнем регистре: " + uppercaseString);
        String lowercaseString = inputString.toLowerCase();
        System.out.println("Строка в нижнем регистре: " + lowercaseString);
        String subStringJava = inputString.substring(inputString.indexOf("Java"));
        System.out.println("Вырезанная подстрока 'Java': " + subStringJava);
        //Задание из собеседования Яндекс:
        //дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
        // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
        // Если буква одна, то цифра не ставится.
        String string = "AAAABBBCCCDDEG";
        String sstring = compressString(string);
        System.out.println("Свернутая строка: " + sstring);
    }

    static String compressString(String input) {
        StringBuilder compressed = new StringBuilder();
        int count = 1;

        for (int i = 1; i < input.length(); i++) {
            if (input.charAt(i) == input.charAt(i - 1)) {
                count++;
            } else {
                compressed.append(input.charAt(i - 1));
                if (count > 1) {
                    compressed.append(count);
                }
                count = 1;
            }
        }

        // Добавление последнего символа и его количество (если больше 1)
        compressed.append(input.charAt(input.length() - 1));
        if (count > 1) {
            compressed.append(count);
        }

        return compressed.toString();
    }
}
