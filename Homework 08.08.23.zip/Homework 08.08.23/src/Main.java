import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Домашнее задание №1,1");
        Random rnd = new Random();
        int number10 = rnd.nextInt();
        System.out.println(number10);
        System.out.println();
        double temperature = rnd.nextDouble(10, 30);
        System.out.println(temperature);
        System.out.println();
        float number11 = rnd.nextFloat();
        System.out.println(number11);
        System.out.println();
        long number12 = rnd.nextLong();
        System.out.println(number12);
        System.out.println();
        int byteInt = rnd.nextInt();
        byte byteRd = (byte) byteInt;
        System.out.println(byteRd);
        System.out.println();
        int shortInt = rnd.nextInt();
        short shortRd = (short) shortInt;
        System.out.println(shortRd);
        System.out.println();
        int charInt = rnd.nextInt();
        char charRd = (char) charInt;
        System.out.println(charRd);
        System.out.println();
        System.out.println("Домашнее задание №1,2");
        String str = "30";
        int i = Byte.parseByte(str);
        System.out.println(i + " лет");
        System.out.println();
        int i1 = 25;
        String s = String.valueOf(i1);
        System.out.println(i1 + " лет - это не возраст");
        System.out.println();
        System.out.println("Домашнее задание №2");
        Scanner scr = new Scanner(System.in);
        System.out.print("Введите ваше имя: ");
        String name = scr.nextLine();
        System.out.print("Введите ваш возраст: ");
        int age = scr.nextInt();
        System.out.print("Введите ваш вес: ");
        int weight = scr.nextInt();
        System.out.println("Уважаемый(-ая) " + name + " !" + "В свои " + age + " лет(-года) Вы для нас дороги, как "
                + weight + " килограмм золота.");
        System.out.println();
        System.out.println("Домашнее задание №3");
        System.out.print("Введите первое число: ");
        int value = scr.nextInt();
        System.out.print("Введите второе число: ");
        int value1 = scr.nextInt();


        System.out.println("Сумма = " + (value + value1) + ", Разность = " + (value - value1) + ", Произведение = "
                + (value * value1) + ", Частное = " + (value / value1));
        System.out.println();
        System.out.print("Сумма = " + (value + value1));
        System.out.println();
        System.out.print("Разность = " + (value - value1));
        System.out.println();
        System.out.print("Произведение = " + (value * value1));
        System.out.println();
        System.out.print("Частное = " + (value / value1));
        System.out.println();
        System.out.println("Дополнительное задание");
        System.out.println();
        double a = Math.random();
        double b = Math.random();
        System.out.println(a);
        System.out.println();
        System.out.println(b);
        System.out.println();
        System.out.println("Разница " + Math.abs(a - b));
        System.out.println();
        System.out.println("Минимум " + Math.min(a, b));
        System.out.println();
        System.out.println("Максимум " + Math.max(a, b));
        System.out.println();
        System.out.println("Максимум " + Math.pow(a, b * 10));







    }
}