import java.time.DayOfWeek;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль. Программа должна вывести все дни недели,
        // кроме данного.
        System.out.println("Введите день недели");
        Scanner scr = new Scanner(System.in);
        String s = scr.nextLine();
        DayOfWeek userDay = DayOfWeek.valueOf(s.toUpperCase(Locale.ROOT));
        for (java.time.DayOfWeek dayOfWeek : java.time.DayOfWeek.values()) {
            if (userDay == dayOfWeek)
                continue;
            System.out.println(dayOfWeek.ordinal() + " " + dayOfWeek.name() + " ");

        }
        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Программу повторять,
        // пока пользователь не введёт «quit».
        do {
            System.out.println("Введите первое число");
            int low = scr.nextInt();
            System.out.println("Введите второе число");
            int up = scr.nextInt();
            low = low % 2 == 0? low +1 : low;
            int sum = 0;
            for (int i = low; i <= up; i+=2) {
                sum = i + sum;
            }
            System.out.println(sum);
            System.out.println("Введите quit для выхода");
        } while (!"quit".equalsIgnoreCase(scr.nextLine()));

        // Задание 1

        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения. Каждый друг случайным образом может
        // подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов. Твоя цель - новенький игровой компьютер,
        // который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше), останавливай сбор подарков и
        // веди всех выпить за твоё здоровье в лучший бар города!
        Random rnd = new Random();
        int money = rnd.nextInt(0, 4);
        int sum = 10000;
        int result = 0;
        while (result <= sum){
            System.out.println(rnd + " Недостаточно денег");
            result += switch (money) {
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                default ->  500;


            };
        }
        System.out.println("Поздравляю вы можете купить новый компьютер");
    }
}