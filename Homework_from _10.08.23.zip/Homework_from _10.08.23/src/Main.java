import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: 1 Дана длина в метрах. Напишите программу, которая переводит указанное значение в км,
        // мили, футы и аршины. Выведите начальное и конвертированные значения на экран.
        //2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”.
        //3 Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather),
        // то ребята пойдут в поход. Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года,
        // то ребята пойдут в поход даже в плохую погоду. В поход ребят должен кто-то повести. Поведёт тренер Джим,
        // если он освободится от сдачи тренерского экзамена (isJimFree), или тренер Кейт,
        // если она вернётся из путешествия (hasKateComeBack). Вести детей может только один тренер.
        // Если Джим и Кейт смогут вести детей вместе, то они обязательно поссорятся из-за этого и никто никуда не пойдёт.
        //Напишите логическое выражение для вычисления того, состоится ли поход.
        // Подберите условия, при которых поход состоится.
        //4 Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
        // Остаток деления можно отбросить. Операторы деления / и остатка от деления % применять нельзя.
        System.out.println("Задание №1");
        System.out.println();
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите длину в метрах");
        double choice = scr.nextDouble();
        double km = 0.001;
        double mile = 0.000621371192;
        double ft = 3.2808399;
        double arshin = 1.40607424;
        System.out.println("Километры = " + km * choice);
        System.out.println("Мили = " + mile * choice);
        System.out.println("Футы = " + ft * choice);
        System.out.println("Аршины = " + arshin * choice);
        System.out.println();
        System.out.println("Задание №2");
        System.out.println();
        System.out.println("Введите стоимость");
        Random rnd = new Random();
        int Sum = scr.nextInt();
        int Rub = rnd.nextInt();
        System.out.println("Сумма сдачи: " + (Sum - Rub));
        System.out.println("Сумма сдачи: " + (Sum - Rub));

        System.out.println();
        System.out.println("Задание №3");
        System.out.println();
        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = false;
        boolean hasHikeHappen = (isJimFree || hasKateComeBack) && (isYearFinished && isGoodWeather &&
                hasBoughtRaincoats);
        System.out.println(hasHikeHappen);
        System.out.println();
        System.out.println("Задание №4");
        System.out.println("Введите первое число");
        int num = scr.nextInt();
        int num1 = 2;
        System.out.println("Результат = " + (num / num1));


    }
}