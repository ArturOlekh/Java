package org.example.call.with.teacher;

public enum TimesOfDay {
    MORNING,
    DAY,
    EVENING,
    NIGHT
}
