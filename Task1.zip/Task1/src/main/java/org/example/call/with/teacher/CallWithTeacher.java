package org.example.call.with.teacher;

import java.util.Random;
import java.util.Scanner;

public class CallWithTeacher {
    private TimesOfDay timesOfDay;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("When would you like to meet with teacher? (morning-1,day-2,evening-3,night-4)");
        int TimesOfDay = scanner.nextInt();

        switch (TimesOfDay){
            case 1:
                System.out.println("morning");
                break;
            case 2:
                System.out.println("day");
                break;
            case 3:
                System.out.println("evening");
                break;
            case 4:
                System.out.println("night");
                break;
            default:
                System.out.println("You have chosen");
                scanner.close();
        }
        

    }

    //2 Программа «Созвон с преподавателем». Создайте перечисление времени суток (утро, день, вечер, ночь).
    // Пользователь вводит, когда он готов созвониться с преподавателем, чтобы задать вопросы по домашнему
    // заданию. Компьютер случайным образом выбирает, в какое время свободен преподаватель.
    // Если время суток совпало, то программа должна вывести «Созвон состоялся». Если не совпало,
    // то программа выводит «не сегодня».
}
