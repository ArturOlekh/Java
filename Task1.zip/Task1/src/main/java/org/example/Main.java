package org.example;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
       // Дан список строк. Подсчитайте общее количество слов во всех строках.
        List<String> list = List.of(
                "Hello my friend",
                "I am glad to see you",
                "See you later");
        list.stream().map(s->s.split(" ")).mapToInt(arr->arr.length).sum();
        list.stream().mapToInt(s->s.split(" ").length).sum();
        list.stream().flatMap(s-> Arrays.stream(s.split(" "))).count();

        //2 Программа «Созвон с преподавателем». Создайте перечисление времени суток (утро, день, вечер, ночь).
        // Пользователь вводит, когда он готов созвониться с преподавателем, чтобы задать вопросы по домашнему
        // заданию. Компьютер случайным образом выбирает, в какое время свободен преподаватель.
        // Если время суток совпало, то программа должна вывести «Созвон состоялся». Если не совпало,
        // то программа выводит «не сегодня».

    }
}