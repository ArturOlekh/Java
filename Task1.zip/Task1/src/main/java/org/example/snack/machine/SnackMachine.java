package org.example.snack.machine;

import java.util.Scanner;

public class SnackMachine {
    public static void main(String[] args) {
        //1 Создайте перечисление с наименованием снеков в снек-автомате.
        //Пользователь вводит номер снека. Автомат сообщает, какой снек был выдан.
        Scanner scr = new Scanner(System.in);
        System.out.println("Enter number of snacks from 1 to 5");
        int snackNumber = scr.nextInt();
        switch (snackNumber){
            case 1:
                System.out.println("Chips");
                break;
            case 2:
                System.out.println("Nuts");
                break;
            case 3:
                System.out.println("Chocolates");
                break;
            case 4:
                System.out.println("Drinks");
                break;
            case 5:
                System.out.println("Lollipops");
                break;
            default:
                System.out.println("Wrong choice, try again from the list");
                scr.close();
        }
        System.out.println("Thank you for your choice");
    }


}
