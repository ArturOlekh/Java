import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Сколько лет вы состоите в браке?  ");
        Anniversary[] anniversaries = Anniversary.values();
        int age = scr.nextInt() + 1;
        if (age > 14){
            System.out.println("Такого числа нет");
            return;
        }
        Anniversary anniversary = anniversaries[age];
        System.out.println("Поздравляем следующая годовщина " + anniversary);


    }
}