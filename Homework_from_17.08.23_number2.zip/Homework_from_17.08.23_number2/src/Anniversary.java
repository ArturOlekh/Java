public enum Anniversary {
    PAPER,
    COTTON,
    LEATHER,
    FRUIT,
    WOOD,
    SUGAR,
    COPPER,
    BRONZE,
    WILLOW,
    TIN,
    STEEL,
    SILK,
    LACE,
    IVORY,
    CRYSTAL
}
