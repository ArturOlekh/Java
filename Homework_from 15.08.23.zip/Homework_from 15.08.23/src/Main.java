import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1 уровень сложности: №1
        //Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например :
        //ввод : m=10.5, n=10.45
        //вывод: Число 10.45 ближе к 10.
        //№2
        //Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Пользователь сам вводит два целых однозначных числа. Программа задаёт вопрос: результат умножения
        // первого числа на второе.  Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        //№3
        //Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите программу,
        // в которой пользователь вводит год. Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
        // Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
        // Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
        System.out.println("Задание №1");
        System.out.println();
        Random rnd = new Random();
        int m = rnd.nextInt(0,10);
        int n = rnd.nextInt(0,10);
        System.out.println(Math.max(m, n));
        System.out.println();
        System.out.println("Задание №2");
        System.out.println();
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое число ");
        int num1 = scr.nextInt();
        System.out.println("Введите второе число ");
        int num2 = scr.nextInt();
        System.out.println("Результат умножения первого числа на второе  ");
        int result = scr.nextInt();
        if (num1 * num2 != result) {
            System.out.println("Правильный ответ " + num1 * num2);
        }
        System.out.println();
        System.out.println("Задание №3");
        System.out.println();
        System.out.println("Введите год рождения Элвиса Пресли ");
        double born = scr.nextDouble();
        double born1 = 1935;
        double born2 = 1977;
        if (born < born1) {
            System.out.println("Элвис ещё не родился");
        }
        if (born > born2) {
            System.out.println("Элвис навсегда в наших сердцах!");
        }
        if (born1 <= born && born <= born2) {
            System.out.println("Элвис жив!");
        }






    }
}