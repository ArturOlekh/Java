import java.time.LocalDate;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
        // Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день),
        // где год, месяц и день – целые числа.
        //Выведите массив в консоль.
        //2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
        //3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
        //Сортировку можно выполнить по любому из изученных алгоритмов

        LocalDate[] dates = {
                LocalDate.of(1991, 6, 3),
                LocalDate.of(1992, 7, 6),
                LocalDate.of(1993, 1, 14),
                LocalDate.of(1994, 2, 15),
                LocalDate.of(1995, 6, 15),
                LocalDate.of(1997, 8, 24),
                LocalDate.of(1990, 10, 7),
                LocalDate.of(1989, 10, 1)
        };
        System.out.print("\nOriginal Array: ");
        System.out.println();
        System.out.println(Arrays.toString(dates));
        sortByYear(dates);
        System.out.println("\nArray sorted by year: ");
        System.out.println(Arrays.toString(dates));
        sortByDay(dates);
        System.out.println("\nArray sorted by day: ");
        System.out.println(Arrays.toString(dates));
    }

    private static void sortByYear(LocalDate[] array) {
        LocalDate temp;
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j].getYear() > array[j + 1].getYear()) {
                    temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    private static void sortByDay(LocalDate[] array) {
        LocalDate temp;
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - i - 1; j++) {
                if (array[j].getDayOfMonth() > array[j + 1].getDayOfMonth()) {
                    temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }
}
