package org.example.common;

public record Result(Currency originalCurrency, double originalAmount, Currency targetcurrency, double targetAmount) {
}
