package org.example.common;

import java.util.Optional;

public final class ResultOrError {
    private final Result result;
    private final String error;

    public ResultOrError(Result result, String error) {
        this.result = result;
        this.error = error;
    }

    public Optional<Result> result() {
        return Optional.ofNullable(result);
    }

    public Optional<String> error() {
        return Optional.ofNullable(error);
    }

    public boolean isError() {
        return error().isPresent();
    }
}
