package org.example.common;

public enum Currency {
    EUR,
    USD,
    GBP,
    JPY,
    BTC,
    UAH,
    QAR,
    PLN,
    OMR

    //todo add more


}
