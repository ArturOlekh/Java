package org.example.common;

public interface RateService {
    ResultOrError convert(double amount, Currency original, Currency target);
}
