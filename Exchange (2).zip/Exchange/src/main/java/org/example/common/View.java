package org.example.common;

import java.util.List;

public interface View {
    double getAmount();
    Currency getOriginalCurrency(List<Currency> supported);
    Currency getTargetCurrency(List<Currency> supported);
    void showResult(ResultOrError resultOrError);
}
