package org.example;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Stream;


public class Main {
    public static void main(String[] args) {

        //Конвертер валют. Приложение, которое получает текущие курсы валют из внешнего API.
        //Конвертация валют с использованием введенных пользователем значений. Сохранение истории
        // конвертаций в локальном файле
//todo
    }
}