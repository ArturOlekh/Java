package org.example.model;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.common.Currency;
import org.example.common.RateService;
import org.example.common.ResultOrError;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;


public class RateServiceImpl implements RateService {
    private final URI uri;

    public RateServiceImpl(URI uri) {
        this.uri = uri;
    }

    @Override
    public ResultOrError convert(double amount, Currency original, Currency target) {
        URI targetUri = appendParams(uri, Map.of("get", "rates",
                "pairs", original + "" + target,
                "key", UUID.randomUUID().toString()));
        try {
            URL url = targetUri.toURL();//протокол,хост,порт,путь,параметры запроса,якорь
            URLConnection connection = url.openConnection();
            connection.connect();
//            OutputStream out = connection.getOutputStream();
//            out.write(1);
//            InputStream input = connection.getInputStream();
//            int data = input.read();
            //мы установили соединение с сервером, теперь работа с Json?
            ObjectMapper obj = new ObjectMapper();
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //Получить курсы для валют:
        //url = https://currate.ru/api/
        //Параметры запроса:
        //get = rates - запрос котировок
        //pairs = валютные пары, разделенные запятой (список пар можно получить методом currency_list)
        //date = Дата и время [опционально], по умолчанию берутся последние данные (GMT +03:00). Пример: &date=2018-02-12T15:00:00
        //key = ваш API-KEY
        //
        //REQUEST:
        //GET: https://currate.ru/api/?get=rates&pairs=USDRUB,EURRUB&key=YOUR-API-KEY
        //
        //RESPONSE (json):
        //{"status":"200","message":"rates","data":{"EURRUB":"71.3846","USDRUB":"58.059"}}
        //Обратите внимание, валютные пары можно задавать в любом порядке USDRUB = 56.311 или RUBUSD = 0.01776
        return null;
    }

    private URI appendParams(URI original, Map<String, String> params) {
        String oldParams = original.getQuery();//take params
        String newParams = (oldParams == null) ? getNewParams(params) : oldParams + "&" + getNewParams(params);
        try {
            return new URI(original.getScheme(), original.getAuthority(), original.getPath(), newParams, original.getFragment());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private String getNewParams(Map<String, String> params) {
        return params.entrySet().stream()
                .map(pair -> pair.getKey() + "=" + pair.getValue())
                .collect(Collectors.joining("&"));
    }


}
