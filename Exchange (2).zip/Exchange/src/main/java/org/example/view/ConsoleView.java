package org.example.view;

import org.example.common.Currency;
import org.example.common.Result;
import org.example.common.ResultOrError;
import org.example.common.View;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class ConsoleView implements View {
    private final Scanner scanner;

    public ConsoleView() {
        this.scanner = new Scanner(System.in);
    }//for get information from user

    @Override
    public double getAmount() {
        System.out.println("Enter amount for conversions:");
        while (true) {
            String s = scanner.nextLine();
            Optional<Double> optionalAmount = parseDouble(s);
            if (optionalAmount.isEmpty()) continue;
            double amount = optionalAmount.get();
            if (amount < 0) {
                System.out.println("Was entering negative amount");
                continue;
            }
            return amount;
        }
    }//for get information from user

    private Optional<Double> parseDouble(String s) {
        try {
            double amount = Double.parseDouble(s);
            return Optional.of(amount);
        } catch (NumberFormatException e) {
            System.err.println("Invalid input. Please, enter numeric value.");
            return Optional.empty();
        }
    }

    @Override
    public Currency getOriginalCurrency(List<Currency> supported) {
        return getCurrency(supported, "original");
    }//chose currency from user

    @Override
    public Currency getTargetCurrency(List<Currency> supported) {
        return getCurrency(supported, "target");
    }//chose currency from user

    private Currency getCurrency(List<Currency> supported, String type) {
        System.out.println("Enter " + type + " currency from supported: " + supported);
        while (true) {
            try {
                String line = scanner.next().toUpperCase();
                Currency currency = Currency.valueOf(line);
                if (supported.contains(currency)) {
                    return currency;
                } else {
                    System.out.println("Currency is not supported. Try again.");
                }
            } catch (IllegalArgumentException e) {
                System.err.println("Invalid input. Try again.");
            }
        }
    }//convert to uppercase, convert to string

    @Override
    public void showResult(ResultOrError resultOrError) {
        if (resultOrError.isError()) {
            System.out.println("Error" + resultOrError.error().orElseThrow());
        } else {
            Result result = resultOrError.result().orElseThrow();
            System.out.printf("Conversions: %.2f %s = %.2f %s%n",
                    result.originalAmount(),
                    result.originalCurrency(),
                    result.targetAmount(),
                    result.targetcurrency());
        }//check for errors and return it
        //get object Result if present
    }
}
